globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/hhi6peYrav1_eLffoxC-8/_buildManifest.js",
    "static/hhi6peYrav1_eLffoxC-8/_ssgManifest.js",
    "static/hhi6peYrav1_eLffoxC-8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/2azih9v8zxhei.js",
    "static/chunks/2vvl0wbxk0b9n.js",
    "static/chunks/166krz0mqm_0c.js",
    "static/chunks/0ay527mnq1105.js",
    "static/chunks/turbopack-2md8vq1znxoh2.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
