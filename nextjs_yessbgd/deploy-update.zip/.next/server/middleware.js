var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0dogjq8._.js")
R.c("server/chunks/[root-of-the-server]__1sl936g._.js")
R.m(62395)
module.exports=R.m(62395).exports
