:HL["/_next/static/chunks/04_wco--yxm07.css","style"]
:HL["/_next/static/chunks/457qv87dvbs-h.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20496,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":20544,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":20640,"slots":null}}}}},"staleTime":300,"buildId":"LiaR2Zv2lUMb1cGs5E3sx"}
