:HL["/_next/static/chunks/04_wco--yxm07.css","style"]
:HL["/_next/static/chunks/0mtebl-qnpz_o.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20496,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":20544,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":20640,"slots":null}}}}},"staleTime":300,"buildId":"hhi6peYrav1_eLffoxC-8"}
