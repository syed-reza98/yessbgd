var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/resumes/[id]/route.js")
R.c("server/chunks/[externals]__0fnlvz3._.js")
R.c("server/chunks/_0panph_._.js")
R.c("server/chunks/_1q71pbq._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_resumes_[id]_route_actions_1zosxm9.js")
R.m(40724)
module.exports=R.m(40724).exports
