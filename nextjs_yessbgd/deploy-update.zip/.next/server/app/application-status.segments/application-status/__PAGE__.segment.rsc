1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[5014,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js","/_next/static/chunks/1ast4kpfkezx_.js"],"default"]
4:I[9610,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js","/_next/static/chunks/1ast4kpfkezx_.js"],"ApplicationStatusTracker"]
5:I[97367,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js"],"OutletBoundary"]
a:I[97367,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js"],"ViewportBoundary"]
b:I[97367,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js"],"MetadataBoundary"]
8:X
8:300
8:300
8:C
9:X
9:C
27:X
27:C
2a:X
2a:C
2c:X
2c:C
0:{"buildId":"LiaR2Zv2lUMb1cGs5E3sx","data":[{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"py-24 text-center","children":[["$","$L3",null,{"icon":{"name":"loader-circle","size":24,"node":[["path",{"d":"M21 12a9 9 0 1 1-6.219-8.56","key":"13zald"}]],"aliases":["loader-2"]},"className":"w-8 h-8 animate-spin mx-auto text-primary"}],["$","p",null,{"className":"mt-3 text-xs text-foreground/70","children":"Loading sovereign candidate session..."}]]}],"children":["$","$L4",null,{"initialSitePage":null,"settings":{"branding":{"companyName":"YESS Bangladesh","companyNameBn":"ইয়েস বাংলাদেশ","legalName":"Yess Bangla Private Limited","registrationNo":"C-184920","logoUrl":"/assets/yess-bangla-logo.png","faviconUrl":"/favicon.png"},"contact":{"phone":"+880 1805-464343","email":"info@yessbd.com","investEmail":"info@yessbd.com","careersEmail":"info@yessbangla.com","whatsapp":"+880 1805-464343","address":"Section-11, Block-A, Main Road-3, Plot-10, Mirpur, Pallabi, Dhaka-1216 (Metro Rail Pillar -312)","addressBn":"সেকশন-১১, ব্লক-এ, মেইন রোড-৩, প্লট-১০, মিরপুর, পল্লবী, ঢাকা-১২১৬ (মেট্রোরেল পিলার -৩১২)"},"offices":{"headquarters":{"name":"Corporate Headquarters","nameBn":"কর্পোরেট হেডকোয়ার্টার","address":"Section-11, Block-A, Main Road-3, Plot-10, Mirpur, Pallabi, Dhaka-1216 (Metro Rail Pillar -312)","addressBn":"সেকশন-১১, ব্লক-এ, মেইন রোড-৩, প্লট-১০, মিরপুর, পল্লবী, ঢাকা-১২১৬ (মেট্রোরেল পিলার -৩১২)","badge":"Metro Rail Pillar -312","hours":"BST 09:00 - 18:00 (Sat - Thu)","lat":23.8253366,"lng":90.3657431,"mapUrl":"https://maps.app.goo.gl/R39sZ5QgTBuTJpEf6"}},"socials":{"twitter":"https://x.com/yessbangla","youtube":"https://youtube.com/@yessbangla","facebook":"https://facebook.com/yessbangla","linkedin":"https://linkedin.com/company/yessbangla"},"header":{"ribbonTextEn":"Dhaka BST Operational","ribbonTextBn":"ঢাকা বিএসটি কার্যকর","ribbonCtaTextEn":"Let's Talk","ribbonCtaTextBn":"যোগাযোগ করুন","ribbonCtaHref":"/contact","trackStatusTextEn":"Track Application","trackStatusTextBn":"আবেদনের অগ্রগতি","trackStatusHref":"/application-status"},"footer":{"missionNarrativeEn":"Pioneering institutional venture building, engineering resilient technological backbone infrastructures, and empowering youth-led socioeconomic transformation across South Asia.","missionNarrativeBn":"প্রাতিষ্ঠানিক ভেঞ্চার গঠন, টেকসই প্রযুক্তিগত ব্যাকবোন অবকাঠামো প্রকৌশল এবং দক্ষিণ এশিয়া জুড়ে যুব-নেতৃত্বাধীন আর্থ-সামাজিক রূপান্তরকে ক্ষমতায়ন করা।","newsletterTitleEn":"Headquarters & Insights","newsletterTitleBn":"হেডকোয়ার্টার এবং গবেষণা অন্তর্দৃষ্টি","newsletterDescEn":"Quarterly macro research, policy briefings, and sovereign technology dispatches delivered to institutional partners.","newsletterDescBn":"প্রাতিষ্ঠানিক অংশীদারদের জন্য ত্রৈমাসিক ম্যাক্রো গবেষণা, নীতিগত ব্রিফিং এবং প্রযুক্তির বার্তা।","candidateTrackerLabelEn":"Candidate Application Tracker →","candidateTrackerLabelBn":"প্রার্থী আবেদন ট্র্যাকার →","candidateTrackerHref":"/application-status","colTitles":{"ventures":"Ventures","governance":"Governance","headquarters":"Headquarters & Insights"}}}}]}],[["$","script","script-0",{"src":"/_next/static/chunks/1ast4kpfkezx_.js","async":true}]],["$","$L5",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":"$9"},{"rsc":["$","$1","h",{"children":[null,["$","$La",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$Lb",null,{"children":["$","$2",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Application Status Tracker | YESS Bangladesh"}],["$","meta","1",{"name":"description","content":"Real-time candidate telemetry for engineering, product, and consulting roles across YESS Bangladesh ventures."}],["$","meta","2",{"name":"author","content":"YESS Bangla Private Limited"}],["$","meta","3",{"name":"keywords","content":"YESS Bangladesh,Yess Soft,Akash OTT,Enterprise Software Bangladesh,Cloud Solutions Dhaka,Venture Studio Bangladesh"}],"$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17","$L18","$L19","$L1a","$L1b","$L1c","$L1d","$L1e","$L1f","$L20","$L21","$L22","$L23","$L24"]}]}]}],"$L25"]}],"isPartial":"$@26","staleTime":"$8","varyParams":"$27"},{"rsc":"$L28","isPartial":"$@29","staleTime":"$8","varyParams":"$2a"}],"isUpgradeableISRFallback":false,"a":"$@2b","rootVaryParams":"$2c","needsRuntimeRequest":"$@2d"}
2e:I[27201,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js"],"IconMark"]
2f:I[39756,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js"],"default"]
30:I[37457,["/_next/static/chunks/30qynrq14y39_.js","/_next/static/chunks/0bdj-0er7ekv5.js","/_next/static/chunks/37r2xauuwu-qd.js"],"default"]
6:null
c:["$","meta","4",{"name":"robots","content":"noindex, nofollow"}]
d:["$","meta","5",{"property":"og:title","content":"Yess Bangla Private Limited — Sovereign Enterprise Studio"}]
e:["$","meta","6",{"property":"og:description","content":"Sovereign enterprise technology, cloud platforms, and venture studios across Bangladesh."}]
f:["$","meta","7",{"property":"og:url","content":"https://yessbd.com"}]
10:["$","meta","8",{"property":"og:site_name","content":"YESS Bangladesh"}]
11:["$","meta","9",{"property":"og:locale","content":"en_US"}]
12:["$","meta","10",{"property":"og:image","content":"https://yessbd.com/og-image.jpg"}]
13:["$","meta","11",{"property":"og:image:type","content":"image/jpeg"}]
14:["$","meta","12",{"property":"og:image:width","content":"1200"}]
15:["$","meta","13",{"property":"og:image:height","content":"630"}]
16:["$","meta","14",{"property":"og:image:alt","content":"Yess Bangla Private Limited — Sovereign Venture Studio & Holding Company"}]
17:["$","meta","15",{"property":"og:locale:alternate","content":"bn_BD"}]
18:["$","meta","16",{"property":"og:type","content":"website"}]
19:["$","meta","17",{"name":"twitter:card","content":"summary_large_image"}]
1a:["$","meta","18",{"name":"twitter:title","content":"Yess Bangla Private Limited — Sovereign Enterprise Studio"}]
1b:["$","meta","19",{"name":"twitter:description","content":"Sovereign enterprise technology, cloud platforms, and venture studios across Bangladesh."}]
1c:["$","meta","20",{"name":"twitter:image","content":"https://yessbd.com/og-image.jpg"}]
1d:["$","link","21",{"rel":"icon","href":"/favicon.ico?favicon.0eny3_346gzwb.ico","sizes":"256x256","type":"image/x-icon"}]
1e:["$","link","22",{"rel":"icon","href":"/favicon.ico","sizes":"any"}]
1f:["$","link","23",{"rel":"icon","href":"/favicon.svg","type":"image/svg+xml"}]
20:["$","link","24",{"rel":"icon","href":"/favicon.png","type":"image/png"}]
21:["$","link","25",{"rel":"icon","href":"/icon-192.png","sizes":"192x192","type":"image/png"}]
22:["$","link","26",{"rel":"icon","href":"/icon-512.png","sizes":"512x512","type":"image/png"}]
23:["$","link","27",{"rel":"apple-touch-icon","href":"/apple-touch-icon.png","sizes":"180x180","type":"image/png"}]
24:["$","$L2e","28",{}]
25:["$","meta",null,{"name":"next-size-adjust","content":""}]
28:["$","$1","c",{"children":[null,["$","$L2f",null,{"parallelRouterKey":"children","template":["$","$L30",null,{}]}]]}]
2d:false
2b:null
26:"$undefined"
29:"$undefined"
7:"$undefined"
