:HL["/_next/static/chunks/04_wco--yxm07.css","style"]
:HL["/_next/static/chunks/457qv87dvbs-h.css","style"]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.2bn3s6zvc0dyp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":12304,"slots":{"children":{"name":"ventures","param":null,"prefetchHints":12352,"slots":{"children":{"name":"slug","param":{"type":"d","key":null,"siblings":[]},"prefetchHints":12384,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":12448,"slots":null}}}}}}},"staleTime":300,"buildId":"LiaR2Zv2lUMb1cGs5E3sx"}
