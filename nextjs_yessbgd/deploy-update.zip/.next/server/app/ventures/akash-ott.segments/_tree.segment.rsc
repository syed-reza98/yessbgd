:HL["/_next/static/chunks/04_wco--yxm07.css","style"]
:HL["/_next/static/chunks/0mtebl-qnpz_o.css","style"]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.2bn3s6zvc0dyp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":28688,"slots":{"children":{"name":"ventures","param":null,"prefetchHints":28736,"slots":{"children":{"name":"slug","param":{"type":"d","key":null,"siblings":[]},"prefetchHints":28768,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":28832,"slots":null}}}}}}},"staleTime":300,"buildId":"hhi6peYrav1_eLffoxC-8"}
